use anchor_lang::prelude::*;

#[error_code]
pub enum EmberError {
    #[msg("Lifespan must be 24 hours, 7 days or 30 days")]
    BadLifespan,
    #[msg("Total fee must be 1% to 5%, including the 1% platform fee")]
    BadFee,
    #[msg("Treasury share must be 25% to 100% of the creator fee")]
    BadTreasuryShare,
    #[msg("Quorum must be 10% to 50%")]
    BadQuorum,
    #[msg("Coin is not live")]
    NotLive,
    #[msg("Coin has ended")]
    Ended,
    #[msg("Coin is dead")]
    Dead,
    #[msg("Slippage limit hit")]
    Slippage,
    #[msg("Per-wallet buy cap reached")]
    WalletCap,
    #[msg("Math overflow")]
    Math,
    #[msg("Nothing to claim")]
    NothingToClaim,
    #[msg("Not the creator")]
    NotCreator,
}
