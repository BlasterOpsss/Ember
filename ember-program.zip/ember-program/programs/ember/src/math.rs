//! Pure fee and curve math. No Solana types, so it is easy to unit test.

pub const BPS: u128 = 10_000;
pub const PLATFORM_FEE_BPS: u64 = 100; // fixed 1%, inside the total
pub const MAX_TOTAL_FEE_BPS: u64 = 500; // 5% cap including platform
pub const MIN_TREASURY_SHARE_BPS: u64 = 2_500; // of the creator fee
pub const MIN_QUORUM_BPS: u64 = 1_000;
pub const MAX_QUORUM_BPS: u64 = 5_000;

#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub struct FeeSplit {
    pub platform: u64,
    pub treasury: u64,
    pub creator: u64,
}

impl FeeSplit {
    pub fn total(&self) -> u64 {
        self.platform + self.treasury + self.creator
    }
}

/// Platform fee first, then the creator fee, of which `treasury_share_bps`
/// goes to the treasury (rounded up so it never falls below its minimum).
pub fn split_fee(amount: u64, total_fee_bps: u64, treasury_share_bps: u64) -> Option<FeeSplit> {
    if !(PLATFORM_FEE_BPS..=MAX_TOTAL_FEE_BPS).contains(&total_fee_bps) {
        return None;
    }
    if !(MIN_TREASURY_SHARE_BPS..=10_000).contains(&treasury_share_bps) {
        return None;
    }
    let a = amount as u128;
    let platform = a * PLATFORM_FEE_BPS as u128 / BPS;
    let creator_fee = a * (total_fee_bps - PLATFORM_FEE_BPS) as u128 / BPS;
    let treasury = (creator_fee * treasury_share_bps as u128 + BPS - 1) / BPS;
    let creator = creator_fee - treasury;
    Some(FeeSplit {
        platform: platform as u64,
        treasury: treasury as u64,
        creator: creator as u64,
    })
}

/// Constant product. Rounds in the pool's favour.
pub fn tokens_out(virtual_sol: u64, virtual_token: u64, sol_in: u64) -> Option<u64> {
    let k = virtual_sol as u128 * virtual_token as u128;
    let new_vs = virtual_sol as u128 + sol_in as u128;
    let new_vt = (k + new_vs - 1) / new_vs;
    u64::try_from((virtual_token as u128).checked_sub(new_vt)?).ok()
}

pub fn sol_out(virtual_sol: u64, virtual_token: u64, tokens_in: u64) -> Option<u64> {
    let k = virtual_sol as u128 * virtual_token as u128;
    let new_vt = virtual_token as u128 + tokens_in as u128;
    let new_vs = (k + new_vt - 1) / new_vt;
    u64::try_from((virtual_sol as u128).checked_sub(new_vs)?).ok()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fee_split_adds_up_and_respects_minimums() {
        let s = split_fee(1_000_000_000, 300, 2_500).unwrap();
        assert_eq!(s.platform, 10_000_000); // 1%
        assert_eq!(s.treasury, 5_000_000); // 25% of the 2% creator fee
        assert_eq!(s.creator, 15_000_000);
        assert_eq!(s.total(), 30_000_000);
    }

    #[test]
    fn rejects_bad_params() {
        assert!(split_fee(1000, 99, 2_500).is_none());
        assert!(split_fee(1000, 501, 2_500).is_none());
        assert!(split_fee(1000, 300, 2_499).is_none());
        assert!(split_fee(1000, 300, 10_001).is_none());
    }

    #[test]
    fn round_trip_never_pays_out_more_than_paid_in() {
        let (vs, vt) = (30_000_000_000u64, 1_000_000_000_000_000u64);
        let t = tokens_out(vs, vt, 1_000_000_000).unwrap();
        let back = sol_out(vs + 1_000_000_000, vt - t, t).unwrap();
        assert!(back <= 1_000_000_000);
    }
}
