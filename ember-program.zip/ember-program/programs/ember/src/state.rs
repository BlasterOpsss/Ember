use anchor_lang::prelude::*;

#[account]
#[derive(InitSpace)]
pub struct Config {
    pub admin: Pubkey, // multisig
    pub platform_wallet: Pubkey,
    pub bump: u8,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq, InitSpace)]
pub enum CoinStatus {
    Live,
    Voting,
    Dead,
}

#[account]
#[derive(InitSpace)]
pub struct Coin {
    pub creator: Pubkey,
    pub mint: Pubkey,
    pub status: CoinStatus,
    pub life_index: u8,
    pub start_ts: i64,
    pub end_ts: i64,
    // Locked at creation, never changed.
    pub lifespan_secs: i64,
    pub total_fee_bps: u16,
    pub treasury_share_bps: u16,
    pub quorum_bps: u16,
    // Curve.
    pub virtual_sol: u64,
    pub virtual_token: u64,
    pub real_sol: u64, // SOL backing the curve, excludes fees and rent
    pub creator_fees_claimable: u64,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct WalletState {
    pub bought_total: u64, // cumulative tokens bought, used for the wallet cap
    pub first_buy_ts: i64,
    pub streak_days: u16,
    pub last_checkin_day: u32,
}
