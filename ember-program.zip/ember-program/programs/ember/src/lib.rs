use anchor_lang::prelude::*;
use anchor_lang::system_program::{transfer, Transfer};
use anchor_spl::associated_token::AssociatedToken;
use anchor_spl::token_2022::spl_token_2022::instruction::AuthorityType;
use anchor_spl::token_interface::{
    mint_to, set_authority, transfer_checked, Mint, MintTo, SetAuthority, TokenAccount,
    TokenInterface, TransferChecked,
};

pub mod errors;
pub mod math;
pub mod state;
use errors::EmberError;
use math::*;
use state::*;

declare_id!("11111111111111111111111111111111"); // replace after `anchor keys sync`

pub const DECIMALS: u8 = 6;
pub const TOTAL_SUPPLY: u64 = 1_000_000_000 * 1_000_000; // 1B tokens
pub const INIT_VIRTUAL_SOL: u64 = 30_000_000_000; // 30 SOL
pub const WALLET_CAP: u64 = TOTAL_SUPPLY / 50; // 2% of supply bought per wallet
pub const LIFESPANS: [i64; 3] = [86_400, 604_800, 2_592_000]; // 24h, 7d, 30d

#[program]
pub mod ember {
    use super::*;

    pub fn initialize_config(ctx: Context<InitializeConfig>, platform_wallet: Pubkey) -> Result<()> {
        let c = &mut ctx.accounts.config;
        c.admin = ctx.accounts.admin.key();
        c.platform_wallet = platform_wallet;
        c.bump = ctx.bumps.config;
        Ok(())
    }

    /// Fee, treasury share, quorum and lifespan are locked here for good.
    pub fn create_coin(
        ctx: Context<CreateCoin>,
        lifespan_secs: i64,
        total_fee_bps: u16,
        treasury_share_bps: u16,
        quorum_bps: u16,
    ) -> Result<()> {
        require!(LIFESPANS.contains(&lifespan_secs), EmberError::BadLifespan);
        require!(
            (PLATFORM_FEE_BPS..=MAX_TOTAL_FEE_BPS).contains(&(total_fee_bps as u64)),
            EmberError::BadFee
        );
        require!(
            (MIN_TREASURY_SHARE_BPS..=10_000).contains(&(treasury_share_bps as u64)),
            EmberError::BadTreasuryShare
        );
        require!(
            (MIN_QUORUM_BPS..=MAX_QUORUM_BPS).contains(&(quorum_bps as u64)),
            EmberError::BadQuorum
        );

        let now = Clock::get()?.unix_timestamp;
        let mint_key = ctx.accounts.mint.key();
        let bump = ctx.bumps.coin;
        {
            let coin = &mut ctx.accounts.coin;
            coin.creator = ctx.accounts.creator.key();
            coin.mint = mint_key;
            coin.status = CoinStatus::Live;
            coin.life_index = 1;
            coin.start_ts = now;
            coin.end_ts = now.checked_add(lifespan_secs).ok_or(EmberError::Math)?;
            coin.lifespan_secs = lifespan_secs;
            coin.total_fee_bps = total_fee_bps;
            coin.treasury_share_bps = treasury_share_bps;
            coin.quorum_bps = quorum_bps;
            coin.virtual_sol = INIT_VIRTUAL_SOL;
            coin.virtual_token = TOTAL_SUPPLY;
            coin.real_sol = 0;
            coin.creator_fees_claimable = 0;
            coin.bump = bump;
        }

        // Seed the three vault PDAs with rent-exempt minimum (system accounts).
        let rent = Rent::get()?.minimum_balance(0);
        for vault in [
            ctx.accounts.sol_vault.to_account_info(),
            ctx.accounts.treasury.to_account_info(),
            ctx.accounts.creator_vault.to_account_info(),
        ] {
            transfer(
                CpiContext::new(
                    ctx.accounts.system_program.to_account_info(),
                    Transfer { from: ctx.accounts.creator.to_account_info(), to: vault },
                ),
                rent,
            )?;
        }

        // Mint the whole supply into the curve vault, then burn the mint authority.
        let seeds: &[&[u8]] = &[b"coin", mint_key.as_ref(), &[bump]];
        mint_to(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                MintTo {
                    mint: ctx.accounts.mint.to_account_info(),
                    to: ctx.accounts.token_vault.to_account_info(),
                    authority: ctx.accounts.coin.to_account_info(),
                },
                &[seeds],
            ),
            TOTAL_SUPPLY,
        )?;
        set_authority(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                SetAuthority {
                    current_authority: ctx.accounts.coin.to_account_info(),
                    account_or_mint: ctx.accounts.mint.to_account_info(),
                },
                &[seeds],
            ),
            AuthorityType::MintTokens,
            None,
        )?;
        Ok(())
    }

    pub fn buy(ctx: Context<Trade>, sol_in: u64, min_tokens_out: u64) -> Result<()> {
        let now = Clock::get()?.unix_timestamp;
        let (split, net, out, mint_key, coin_bump, coin_key) = {
            let coin = &mut ctx.accounts.coin;
            require!(coin.status == CoinStatus::Live, EmberError::NotLive);
            require!(now < coin.end_ts, EmberError::Ended);
            let split = split_fee(sol_in, coin.total_fee_bps as u64, coin.treasury_share_bps as u64)
                .ok_or(EmberError::BadFee)?;
            let net = sol_in.checked_sub(split.total()).ok_or(EmberError::Math)?;
            let out = tokens_out(coin.virtual_sol, coin.virtual_token, net).ok_or(EmberError::Math)?;
            require!(out > 0 && out >= min_tokens_out, EmberError::Slippage);
            require!(ctx.accounts.token_vault.amount >= out, EmberError::Math);

            let ws = &mut ctx.accounts.wallet_state;
            if ws.first_buy_ts == 0 {
                ws.first_buy_ts = now;
            }
            ws.bought_total = ws.bought_total.checked_add(out).ok_or(EmberError::Math)?;
            require!(ws.bought_total <= WALLET_CAP, EmberError::WalletCap);

            coin.virtual_sol = coin.virtual_sol.checked_add(net).ok_or(EmberError::Math)?;
            coin.virtual_token = coin.virtual_token.checked_sub(out).ok_or(EmberError::Math)?;
            coin.real_sol = coin.real_sol.checked_add(net).ok_or(EmberError::Math)?;
            coin.creator_fees_claimable =
                coin.creator_fees_claimable.checked_add(split.creator).ok_or(EmberError::Math)?;
            (split, net, out, coin.mint, coin.bump, ctx.accounts.coin.key())
        };

        let user = ctx.accounts.user.to_account_info();
        let sys = ctx.accounts.system_program.to_account_info();
        let pay_in = |to: AccountInfo, amt: u64| -> Result<()> {
            if amt == 0 {
                return Ok(());
            }
            transfer(
                CpiContext::new(sys.clone(), Transfer { from: user.clone(), to }),
                amt,
            )
        };
        pay_in(ctx.accounts.sol_vault.to_account_info(), net)?;
        pay_in(ctx.accounts.platform_wallet.to_account_info(), split.platform)?;
        pay_in(ctx.accounts.treasury.to_account_info(), split.treasury)?;
        pay_in(ctx.accounts.creator_vault.to_account_info(), split.creator)?;

        let _ = coin_key;
        let seeds: &[&[u8]] = &[b"coin", mint_key.as_ref(), &[coin_bump]];
        transfer_checked(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.token_vault.to_account_info(),
                    mint: ctx.accounts.mint.to_account_info(),
                    to: ctx.accounts.user_token.to_account_info(),
                    authority: ctx.accounts.coin.to_account_info(),
                },
                &[seeds],
            ),
            out,
            DECIMALS,
        )
    }

    pub fn sell(ctx: Context<Trade>, tokens_in: u64, min_sol_out: u64) -> Result<()> {
        let now = Clock::get()?.unix_timestamp;
        let (split, payout, coin_key, sol_bump) = {
            let coin = &mut ctx.accounts.coin;
            require!(coin.status == CoinStatus::Live, EmberError::NotLive);
            require!(now < coin.end_ts, EmberError::Ended);
            let gross = sol_out(coin.virtual_sol, coin.virtual_token, tokens_in).ok_or(EmberError::Math)?;
            require!(coin.real_sol >= gross, EmberError::Math);
            let split = split_fee(gross, coin.total_fee_bps as u64, coin.treasury_share_bps as u64)
                .ok_or(EmberError::BadFee)?;
            let payout = gross.checked_sub(split.total()).ok_or(EmberError::Math)?;
            require!(payout > 0 && payout >= min_sol_out, EmberError::Slippage);

            coin.virtual_sol = coin.virtual_sol.checked_sub(gross).ok_or(EmberError::Math)?;
            coin.virtual_token = coin.virtual_token.checked_add(tokens_in).ok_or(EmberError::Math)?;
            coin.real_sol = coin.real_sol.checked_sub(gross).ok_or(EmberError::Math)?;
            coin.creator_fees_claimable =
                coin.creator_fees_claimable.checked_add(split.creator).ok_or(EmberError::Math)?;
            (split, payout, ctx.accounts.coin.key(), ctx.bumps.sol_vault)
        };

        // Tokens back into the curve vault (user signs).
        transfer_checked(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                TransferChecked {
                    from: ctx.accounts.user_token.to_account_info(),
                    mint: ctx.accounts.mint.to_account_info(),
                    to: ctx.accounts.token_vault.to_account_info(),
                    authority: ctx.accounts.user.to_account_info(),
                },
            ),
            tokens_in,
            DECIMALS,
        )?;

        // SOL out of the vault PDA.
        let seeds: &[&[u8]] = &[b"sol_vault", coin_key.as_ref(), &[sol_bump]];
        let from = ctx.accounts.sol_vault.to_account_info();
        let sys = ctx.accounts.system_program.to_account_info();
        let pay_out = |to: AccountInfo, amt: u64| -> Result<()> {
            if amt == 0 {
                return Ok(());
            }
            transfer(
                CpiContext::new_with_signer(sys.clone(), Transfer { from: from.clone(), to }, &[seeds]),
                amt,
            )
        };
        pay_out(ctx.accounts.user.to_account_info(), payout)?;
        pay_out(ctx.accounts.platform_wallet.to_account_info(), split.platform)?;
        pay_out(ctx.accounts.treasury.to_account_info(), split.treasury)?;
        pay_out(ctx.accounts.creator_vault.to_account_info(), split.creator)
    }

    /// Claimable any time while the coin is alive (Live or Voting).
    pub fn claim_creator_fees(ctx: Context<ClaimCreatorFees>) -> Result<()> {
        let coin = &mut ctx.accounts.coin;
        require!(coin.status != CoinStatus::Dead, EmberError::Dead);
        let amount = coin.creator_fees_claimable;
        require!(amount > 0, EmberError::NothingToClaim);
        coin.creator_fees_claimable = 0;

        let coin_key = ctx.accounts.coin.key();
        let seeds: &[&[u8]] = &[b"creator_vault", coin_key.as_ref(), &[ctx.bumps.creator_vault]];
        transfer(
            CpiContext::new_with_signer(
                ctx.accounts.system_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.creator_vault.to_account_info(),
                    to: ctx.accounts.creator.to_account_info(),
                },
                &[seeds],
            ),
            amount,
        )
    }
}

#[derive(Accounts)]
pub struct InitializeConfig<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,
    #[account(init, payer = admin, space = 8 + Config::INIT_SPACE, seeds = [b"config"], bump)]
    pub config: Account<'info, Config>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CreateCoin<'info> {
    #[account(mut)]
    pub creator: Signer<'info>,
    #[account(init, payer = creator, space = 8 + Coin::INIT_SPACE,
        seeds = [b"coin", mint.key().as_ref()], bump)]
    pub coin: Account<'info, Coin>,
    #[account(init, payer = creator, mint::decimals = DECIMALS, mint::authority = coin,
        mint::token_program = token_program)]
    pub mint: InterfaceAccount<'info, Mint>,
    #[account(init, payer = creator, associated_token::mint = mint,
        associated_token::authority = coin, associated_token::token_program = token_program)]
    pub token_vault: InterfaceAccount<'info, TokenAccount>,
    #[account(mut, seeds = [b"sol_vault", coin.key().as_ref()], bump)]
    pub sol_vault: SystemAccount<'info>,
    #[account(mut, seeds = [b"treasury", coin.key().as_ref()], bump)]
    pub treasury: SystemAccount<'info>,
    #[account(mut, seeds = [b"creator_vault", coin.key().as_ref()], bump)]
    pub creator_vault: SystemAccount<'info>,
    pub token_program: Interface<'info, TokenInterface>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Trade<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    #[account(seeds = [b"config"], bump = config.bump)]
    pub config: Account<'info, Config>,
    #[account(mut, seeds = [b"coin", mint.key().as_ref()], bump = coin.bump, has_one = mint)]
    pub coin: Account<'info, Coin>,
    pub mint: InterfaceAccount<'info, Mint>,
    #[account(mut, associated_token::mint = mint, associated_token::authority = coin,
        associated_token::token_program = token_program)]
    pub token_vault: InterfaceAccount<'info, TokenAccount>,
    #[account(init_if_needed, payer = user, associated_token::mint = mint,
        associated_token::authority = user, associated_token::token_program = token_program)]
    pub user_token: InterfaceAccount<'info, TokenAccount>,
    #[account(mut, seeds = [b"sol_vault", coin.key().as_ref()], bump)]
    pub sol_vault: SystemAccount<'info>,
    #[account(mut, seeds = [b"treasury", coin.key().as_ref()], bump)]
    pub treasury: SystemAccount<'info>,
    #[account(mut, seeds = [b"creator_vault", coin.key().as_ref()], bump)]
    pub creator_vault: SystemAccount<'info>,
    /// CHECK: must equal the wallet stored in config.
    #[account(mut, address = config.platform_wallet)]
    pub platform_wallet: UncheckedAccount<'info>,
    #[account(init_if_needed, payer = user, space = 8 + WalletState::INIT_SPACE,
        seeds = [b"wallet", coin.key().as_ref(), user.key().as_ref()], bump)]
    pub wallet_state: Account<'info, WalletState>,
    pub token_program: Interface<'info, TokenInterface>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ClaimCreatorFees<'info> {
    #[account(mut, address = coin.creator @ EmberError::NotCreator)]
    pub creator: Signer<'info>,
    #[account(mut)]
    pub coin: Account<'info, Coin>,
    #[account(mut, seeds = [b"creator_vault", coin.key().as_ref()], bump)]
    pub creator_vault: SystemAccount<'info>,
    pub system_program: Program<'info, System>,
}
