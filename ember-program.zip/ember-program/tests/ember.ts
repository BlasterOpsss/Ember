import * as anchor from "@coral-xyz/anchor";
import { BN, Program } from "@coral-xyz/anchor";
import { Keypair, PublicKey, SystemProgram, LAMPORTS_PER_SOL } from "@solana/web3.js";
import {
  ASSOCIATED_TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID,
  getAssociatedTokenAddressSync, getAccount,
} from "@solana/spl-token";
import { assert } from "chai";

const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);
const program = anchor.workspace.Ember as Program<any>;
const pid = program.programId;
const pda = (seeds: (Buffer | Uint8Array)[]) => PublicKey.findProgramAddressSync(seeds, pid)[0];
const SOL = (n: number) => new BN(Math.round(n * LAMPORTS_PER_SOL));

async function fails(p: Promise<any>, text: string) {
  try { await p; } catch (e: any) {
    assert.include(String(e), text); return;
  }
  assert.fail(`expected failure containing: ${text}`);
}

describe("ember", () => {
  const platform = Keypair.generate();
  const config = pda([Buffer.from("config")]);
  const mint = Keypair.generate();
  const coin = pda([Buffer.from("coin"), mint.publicKey.toBuffer()]);
  const solVault = pda([Buffer.from("sol_vault"), coin.toBuffer()]);
  const treasury = pda([Buffer.from("treasury"), coin.toBuffer()]);
  const creatorVault = pda([Buffer.from("creator_vault"), coin.toBuffer()]);
  const tokenVault = getAssociatedTokenAddressSync(mint.publicKey, coin, true, TOKEN_2022_PROGRAM_ID);
  const user = provider.wallet.publicKey;
  const userToken = getAssociatedTokenAddressSync(mint.publicKey, user, false, TOKEN_2022_PROGRAM_ID);
  const walletState = pda([Buffer.from("wallet"), coin.toBuffer(), user.toBuffer()]);

  const createAccounts = (m: Keypair) => {
    const c = pda([Buffer.from("coin"), m.publicKey.toBuffer()]);
    return {
      creator: user, coin: c, mint: m.publicKey,
      tokenVault: getAssociatedTokenAddressSync(m.publicKey, c, true, TOKEN_2022_PROGRAM_ID),
      solVault: pda([Buffer.from("sol_vault"), c.toBuffer()]),
      treasury: pda([Buffer.from("treasury"), c.toBuffer()]),
      creatorVault: pda([Buffer.from("creator_vault"), c.toBuffer()]),
      tokenProgram: TOKEN_2022_PROGRAM_ID,
      associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
      systemProgram: SystemProgram.programId,
    };
  };
  const tradeAccounts = {
    user, config, coin, mint: mint.publicKey, tokenVault, userToken, solVault, treasury,
    creatorVault, platformWallet: platform.publicKey, walletState,
    tokenProgram: TOKEN_2022_PROGRAM_ID,
    associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
    systemProgram: SystemProgram.programId,
  };
  const bal = (k: PublicKey) => provider.connection.getBalance(k);

  it("initializes config", async () => {
    await program.methods.initializeConfig(platform.publicKey)
      .accounts({ admin: user, config, systemProgram: SystemProgram.programId }).rpc();
    const c = await program.account.config.fetch(config);
    assert.equal(c.platformWallet.toBase58(), platform.publicKey.toBase58());
  });

  it("rejects bad launch parameters", async () => {
    const cases: [number, number, number, number, string][] = [
      [1000, 300, 5000, 1000, "BadLifespan"],
      [604800, 600, 5000, 1000, "BadFee"],
      [604800, 50, 5000, 1000, "BadFee"],
      [604800, 300, 2000, 1000, "BadTreasuryShare"],
      [604800, 300, 5000, 500, "BadQuorum"],
      [604800, 300, 5000, 6000, "BadQuorum"],
    ];
    for (const [life, fee, share, quorum, err] of cases) {
      const m = Keypair.generate();
      await fails(
        program.methods.createCoin(new BN(life), fee, share, quorum)
          .accounts(createAccounts(m)).signers([m]).rpc(), err);
    }
  });

  it("creates a coin with locked settings and full supply in the vault", async () => {
    await program.methods.createCoin(new BN(604800), 300, 5000, 1000)
      .accounts(createAccounts(mint)).signers([mint]).rpc();
    const c = await program.account.coin.fetch(coin);
    assert.equal(c.totalFeeBps, 300);
    assert.equal(c.treasuryShareBps, 5000);
    assert.equal(c.quorumBps, 1000);
    assert.equal(c.lifeIndex, 1);
    const v = await getAccount(provider.connection, tokenVault, "confirmed", TOKEN_2022_PROGRAM_ID);
    assert.equal(v.amount.toString(), "1000000000000000");
  });

  it("buy splits fees exactly: 1% platform, 1% treasury, 1% creator", async () => {
    const [p0, t0, c0] = await Promise.all([bal(platform.publicKey), bal(treasury), bal(creatorVault)]);
    await program.methods.buy(SOL(0.5), new BN(1)).accounts(tradeAccounts).rpc();
    assert.equal((await bal(platform.publicKey)) - p0, 5_000_000);
    assert.equal((await bal(treasury)) - t0, 5_000_000);
    assert.equal((await bal(creatorVault)) - c0, 5_000_000);
    const c = await program.account.coin.fetch(coin);
    assert.equal(c.realSol.toString(), "485000000");
    assert.equal(c.creatorFeesClaimable.toString(), "5000000");
    const u = await getAccount(provider.connection, userToken, "confirmed", TOKEN_2022_PROGRAM_ID);
    assert.isTrue(u.amount > 0n);
  });

  it("enforces the 2% per-wallet buy cap", async () => {
    await fails(program.methods.buy(SOL(0.5), new BN(1)).accounts(tradeAccounts).rpc(), "WalletCap");
  });

  it("enforces slippage on buy", async () => {
    await fails(
      program.methods.buy(SOL(0.01), new BN("1000000000000000")).accounts(tradeAccounts).rpc(),
      "Slippage");
  });

  it("creator claims fees any time while alive, once", async () => {
    const before = await bal(creatorVault);
    await program.methods.claimCreatorFees()
      .accounts({ creator: user, coin, creatorVault, systemProgram: SystemProgram.programId }).rpc();
    assert.equal(before - (await bal(creatorVault)), 5_000_000);
    await fails(
      program.methods.claimCreatorFees()
        .accounts({ creator: user, coin, creatorVault, systemProgram: SystemProgram.programId }).rpc(),
      "NothingToClaim");
  });

  it("sell returns SOL minus fees and never drains more than the pool holds", async () => {
    const u = await getAccount(provider.connection, userToken, "confirmed", TOKEN_2022_PROGRAM_ID);
    const half = new BN((u.amount / 2n).toString());
    const before = await program.account.coin.fetch(coin);
    await program.methods.sell(half, new BN(1)).accounts(tradeAccounts).rpc();
    const after = await program.account.coin.fetch(coin);
    assert.isTrue(after.realSol.lt(before.realSol));
    assert.isTrue(after.realSol.gtn(0));
    // pool SOL on-chain must cover the tracked real_sol (plus rent seed)
    assert.isTrue((await bal(solVault)) >= after.realSol.toNumber());
  });

  it("only the creator can claim", async () => {
    const other = Keypair.generate();
    await provider.connection.requestAirdrop(other.publicKey, LAMPORTS_PER_SOL);
    await fails(
      program.methods.claimCreatorFees()
        .accounts({ creator: other.publicKey, coin, creatorVault, systemProgram: SystemProgram.programId })
        .signers([other]).rpc(), "NotCreator");
  });
});
