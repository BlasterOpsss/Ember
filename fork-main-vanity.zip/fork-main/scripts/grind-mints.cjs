#!/usr/bin/env node
/* Grind vanity mint addresses (no dependencies). Usage:
     node scripts/grind-mints.cjs <suffix> [count=5] [threads=cpus]
   Writes netlify/lib/vanity-pool.json (git-ignored: it holds the mints' secret keys) and appends to it if present.
   Then set VANITY_SUFFIX=<suffix> in the site's environment. Each mint is used for one coin only. */
const { Worker, isMainThread, parentPort, workerData } = require('node:worker_threads');
const { generateKeyPairSync } = require('node:crypto');
const fs = require('node:fs'), path = require('node:path'), os = require('node:os');
const A = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const b58 = buf => {
  let n = BigInt('0x' + buf.toString('hex')), s = '';
  while (n > 0n) { s = A[Number(n % 58n)] + s; n /= 58n; }
  for (const b of buf) { if (b) break; s = '1' + s; }
  return s;
};
const b64u = s => Buffer.from(s, 'base64url');

if (isMainThread) {
  const [suffix, count = '5', threads = String(os.cpus().length)] = process.argv.slice(2);
  if (!suffix || [...suffix].some(c => !A.includes(c))) { console.error('usage: grind-mints.cjs <base58 suffix> [count] [threads]  (no 0 O I l)'); process.exit(1); }
  const file = path.join(__dirname, '..', 'netlify', 'lib', 'vanity-pool.json');
  let pool = []; try { pool = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { }
  const want = Number(count); let found = 0, tried = 0; const t0 = Date.now(); const ws = [];
  console.log(`grinding ${want} address(es) ending in "${suffix}" on ${threads} thread(s) — about ${Math.round(Math.pow(58, suffix.length) / 1e6)}M tries each on average`);
  const finish = () => { ws.forEach(w => w.terminate()); fs.writeFileSync(file, JSON.stringify(pool)); console.log(`saved ${pool.length} in ${file}`); process.exit(0); };
  for (let i = 0; i < Number(threads); i++) {
    const w = new Worker(__filename, { workerData: { suffix } }); ws.push(w);
    w.on('message', m => {
      if (m.tick) { tried += m.tick; return; }
      if (found >= want) return;
      pool.push(m); found++; console.log(`${found}/${want}  ${m.address}  (${Math.round((Date.now() - t0) / 1000)}s, ${Math.round(tried / 1e3)}k tries)`);
      if (found >= want) finish();
    });
  }
} else {
  const { suffix } = workerData; let n = 0;
  for (;;) {
    const { publicKey, privateKey } = generateKeyPairSync('ed25519');
    const pub = b64u(publicKey.export({ format: 'jwk' }).x);
    const addr = b58(pub);
    if (addr.endsWith(suffix)) {
      const seed = b64u(privateKey.export({ format: 'jwk' }).d);
      parentPort.postMessage({ address: addr, secret: [...Buffer.concat([seed, pub])] });
    }
    if (++n % 20000 === 0) parentPort.postMessage({ tick: 20000 });
  }
}
